
		function openForm() {
			document.getElementById("myForm").style.display = "block";
		}

		function closeForm() {
			document.getElementById("myForm").style.display = "none";
		}
		function openTaskRequestForm() {
			document.getElementById("myTaskRequestForm").style.display = "block";
		}
		function closeTaskRequestForm() {
			document.getElementById("myTaskRequestForm").style.display = "none";
		}
		function openUpdateTask() {
			var sel = document.getElementById('taskName');
			for (var i = 0; i < taskNames.myArrayList.length; i++) {
				var opt = document.createElement('option');
				opt.appendChild(document
						.createTextNode(taskNames.myArrayList[i].map.taskname));
				opt.value = taskNames.myArrayList[i].map.idtasks;
				sel.appendChild(opt);
			}
			document.getElementById("updateStatusForm").style.display = "block";
		}
		function cancelStatusUpdate() {
			document.getElementById("updateStatusForm").style.display = "none";
		}

		var taskNames;
		function init() {
			var xhr = new XMLHttpRequest();
			xhr.onreadystatechange = function() {
				if (xhr.readyState == 4) {
					var data = xhr.responseText;
					var obj = JSON.parse(data);
					taskNames = obj;
					var table = document.getElementById("tasks-table");
					var rowCount = table.rows.length;
					if (rowCount == 1) {
						for (var i = 0; i < obj.myArrayList.length; i++) {
							var row = table.insertRow(rowCount);
							var cell1 = row.insertCell(0);
							var element1 = document.createElement("td");
							element1
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.idtasks));
							cell1.appendChild(element1);

							var cell2 = row.insertCell(1);
							var element2 = document.createElement("td");
							element2
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.taskname));
							cell2.appendChild(element2);

							var cell3 = row.insertCell(2);
							var element3 = document.createElement("td");
							element3
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.description));
							cell3.appendChild(element3);

							var cell4 = row.insertCell(3);
							var element4 = document.createElement("td");
							element4
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.assignedon));
							cell4.appendChild(element4);

							var cell5 = row.insertCell(4);
							var element5 = document.createElement("td");
							element5
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.dueon));
							cell5.appendChild(element5);

							var cell6 = row.insertCell(5);
							var element6 = document.createElement("td");
							element6
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.status));
							cell6.appendChild(element6);
							rowCount = rowCount + 1;
						}
					}

				}
			}
			xhr.open('GET', '${pageContext.request.contextPath}/UserTaskList',
					true);
			xhr.send(null);
			document.getElementById("projects-section").style.display = "none";
			document.getElementById("teams-section").style.display = "none";
			document.getElementById("tasks-section").style.display = "none";
		}
		function projectsNav() {
			document.getElementById("projects-li").classList.add('active');
			document.getElementById("home-li").classList.remove('active');
			document.getElementById("main-content").style.display = "none";
			document.getElementById("teams-section").style.display = "none";
			document.getElementById("projects-section").style.display = "block";
			document.getElementById("tasks-section").style.display = "none";
			var xhr = new XMLHttpRequest();
			xhr.onreadystatechange = function() {
				if (xhr.readyState == 4) {
					var data = xhr.responseText;
					var obj = JSON.parse(data);
					var table = document.getElementById("projects-table");
					var rowCount = table.rows.length;
					if (rowCount == 1) {
						for (var i = 0; i < obj.myArrayList.length; i++) {
							var row = table.insertRow(rowCount);
							var cell1 = row.insertCell(0);
							var element1 = document.createElement("td");
							element1
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.idprojects));
							cell1.appendChild(element1);

							var cell2 = row.insertCell(1);
							var element2 = document.createElement("td");
							element2
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.projname));
							cell2.appendChild(element2);

							var cell3 = row.insertCell(2);
							var element3 = document.createElement("td");
							element3
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.projdesc));
							cell3.appendChild(element3);

							var cell4 = row.insertCell(3);
							var element4 = document.createElement("td");
							element4
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.begda));
							cell4.appendChild(element4);

							var cell5 = row.insertCell(4);
							var element5 = document.createElement("td");
							element5
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.endda));
							cell5.appendChild(element5);

							var cell6 = row.insertCell(5);
							var element6 = document.createElement("td");
							element6
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.status));
							cell6.appendChild(element6);
							rowCount = rowCount + 1;
						}
					}

				}
			}
			xhr.open('GET',
					'${pageContext.request.contextPath}/ProjectUserServlet',
					true);
			xhr.send(null);

		}

		function teamsNav() {
			document.getElementById("projects-li").classList.remove('active');
			document.getElementById("home-li").classList.remove('active');
			document.getElementById("teams-li").classList.add('active');
			document.getElementById("tasks-li").classList.remove('active');
			document.getElementById("teams-section").style.display = "block";
			document.getElementById("main-content").style.display = "none";
			document.getElementById("tasks-section").style.display = "none";
			document.getElementById("projects-section").style.display = "none";
			var xhr = new XMLHttpRequest();
			xhr.onreadystatechange = function() {
				if (xhr.readyState == 4) {
					var data = xhr.responseText;
					var obj = JSON.parse(data);
					var table = document.getElementById("teams-table");
					var rowCount = table.rows.length;
					if (rowCount == 1) {
						for (var i = 0; i < obj.myArrayList.length; i++) {
							var row = table.insertRow(rowCount);
							var cell1 = row.insertCell(0);
							var element1 = document.createElement("td");
							element1
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.name));
							cell1.appendChild(element1);

							var cell2 = row.insertCell(1);
							var element2 = document.createElement("td");
							element2
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.idemployee_central));
							cell2.appendChild(element2);

							var cell3 = row.insertCell(2);
							var element3 = document.createElement("td");
							element3
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.team));
							cell3.appendChild(element3);

							var cell4 = row.insertCell(3);
							var element4 = document.createElement("td");
							element4
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.join_date));
							cell4.appendChild(element4);

							var cell5 = row.insertCell(4);
							var element5 = document.createElement("td");
							element5
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.manager));
							cell5.appendChild(element5);
							rowCount = rowCount + 1;
						}
					}
				}
			}
			xhr.open('GET', '${pageContext.request.contextPath}/UserTeams',
					true);
			xhr.send(null);
		}

		function tasksNav() {
			document.getElementById("projects-li").classList.remove('active');
			document.getElementById("home-li").classList.remove('active');
			document.getElementById("teams-li").classList.remove('active');
			document.getElementById("tasks-li").classList.add('active');
			document.getElementById("teams-section").style.display = "none";
			document.getElementById("main-content").style.display = "none";
			document.getElementById("tasks-section").style.display = "block";
			document.getElementById("projects-section").style.display = "none";
			var xhr = new XMLHttpRequest();
			xhr.onreadystatechange = function() {
				if (xhr.readyState == 4) {
					var data = xhr.responseText;
					var obj = JSON.parse(data);
					var table = document.getElementById("tasksMain-table");
					var rowCount = table.rows.length;
					if (rowCount == 1) {
						for (var i = 0; i < obj.myArrayList.length; i++) {
							var row = table.insertRow(rowCount);
							var cell1 = row.insertCell(0);
							var element1 = document.createElement("td");
							element1
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.idtasks));
							cell1.appendChild(element1);

							var cell2 = row.insertCell(1);
							var element2 = document.createElement("td");
							element2
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.taskname));
							cell2.appendChild(element2);

							var cell3 = row.insertCell(2);
							var element3 = document.createElement("td");
							element3
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.description));
							cell3.appendChild(element3);

							var cell4 = row.insertCell(3);
							var element4 = document.createElement("td");
							element4
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.assignedTo));
							cell4.appendChild(element4);

							var cell5 = row.insertCell(4);
							var element5 = document.createElement("td");
							element5
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.assignedon));
							cell5.appendChild(element5);

							var cell6 = row.insertCell(5);
							var element6 = document.createElement("td");
							element6
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.dueon));
							cell6.appendChild(element6);
							rowCount = rowCount + 1;

							var cell7 = row.insertCell(6);
							var element7 = document.createElement("td");
							element7
									.appendChild(document
											.createTextNode(obj.myArrayList[i].map.status));
							cell7.appendChild(element7);

							rowCount = rowCount + 1;
						}
					}

				}
			}
			xhr.open('GET', '${pageContext.request.contextPath}/UserTaskList',
					true);
			xhr.send(null);
		}

		function homeNav() {
			document.getElementById("projects-li").classList.remove('active');
			document.getElementById("home-li").classList.add('active');
			document.getElementById("teams-section").style.display = "none";
			document.getElementById("tasks-section").style.display = "none";
			document.getElementById("main-content").style.display = "block";
			document.getElementById("projects-section").style.display = "none";
		}
		function signOut() {
		    /*var auth2 = gapi.auth2.getAuthInstance();
		    auth2.signOut().then(function () {
		      console.log('User signed out.');
		    });*/
		    window.location = 'login.jsp';
		  }
