use database.properties
write test cases

"Functional components of the project
1. Manager : Manager can add team members, Manager can create project with details,
2. Manager can select team member and then assign tasks to team member, Manager can approve suggested task. Manager should be able to see the tasks project wise and team member wise.
3. Team Member: Team member can add tasks by choice. Only approved task by manager will appear on screen. Team member can mark progress of assigned task.
4. When manager assigns task to team member, an email should be sent. 
5. Manager should be able to view the progress made on assigned tasks done 
    - By selecting team member wise task
    - By selecting task
    - By daywise
    - By Pending taks,approved,rejected tasks
6. ON Manager login , he should be able to view all the tasks assigned to team members
7.  Manager/User should be able able to generate reports based on taks that are with status as pending/approved/rejected"




"a) User Login
b) Task planner
  - Add, update, delete tasks
  - Assign Tasks
  - check Task status
c) Data Appender
  - Add, Remove team members 
  - Add, remove project details
d) Task Progress
  - mark the progress(open, 
     Inprogress, close)
e) Report
    - Tasks, projects, users
f) E-mail Alerts
"


Java/J2EE - Servlets, JSP, JavaScript, AJAX, Tomcat 6.0, Oracle 10g
