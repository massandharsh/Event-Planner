package net.login.DataOper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.xdevapi.Statement;

import net.login.bean.LoginBean;

public class DashSummary {
	Connection connection;

	public DashSummary() {
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1:3306/employees?allowPublicKeyRetrieval=true&useSSL=false", "root", "admin");
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public int getProjectCount(String user) throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Statement stmt = null;
		ResultSet rs = null;
		int projectCount = 0;
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery("select count(*) from projects where createdby = " + "'" + user + "'");
			rs.next();
			projectCount = rs.getInt("count(*)");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return projectCount;
	}
	
	 public List<Category> projectList(String user) throws ClassNotFoundException {
	        List<Category> listCategory = new ArrayList<>();
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Statement stmt = null;
		ResultSet rs = null;
		
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery("SELECT * FROM projects where createdby = '"+user+"';" );
			
			while (rs.next()) {
				String id = rs.getString("projname");
                String name = rs.getString("projname");
                Category category = new Category(id, name);
                     
                listCategory.add(category);
            }        
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return listCategory;
	}
	 
	 public List<Category> membersList(String user) throws ClassNotFoundException {
	        List<Category> listCategory = new ArrayList<>();
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Statement stmt = null;
		ResultSet rs = null;
		
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery("SELECT * FROM employee_central WHERE managerid = " + "'" + user + "'");
			while (rs.next()) {
				String id = rs.getString("idemployee_central");
             String name = rs.getString("name");
             Category category = new Category(id, name);  
             listCategory.add(category);
         }        
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return listCategory;
	}

	public int getTaskInProcessCount(String user) throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Statement stmt = null;
		ResultSet rs = null;
		int taskInProcessCount = 0;
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery("select count(*) from tasks where status = 'In-Process'and createdby = " + "'" + user + "'" );
			rs.next();
			taskInProcessCount = rs.getInt("count(*)");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return taskInProcessCount;
	}

	public int getTaskCompletedCount(String user) throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Statement stmt = null;
		ResultSet rs = null;
		int taskCompletedCount = 0;
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery("select count(*) from tasks where status = 'Completed' and createdby = " + "'" + user + "'");
			rs.next();
			taskCompletedCount = rs.getInt("count(*)");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return taskCompletedCount;
	}

	public String[] getTeamCount(String uname) throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Statement stmt = null;
		ResultSet rs = null;
		String members;
		String[] memArr = null;
		String query = "select teammembers from team where manager = "+"'"+uname+"'";
//		/System.out.println(uname);
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(query);
			rs.next();
			members = rs.getString("teammembers");
//			if(rs.next() && (members!="" || members!=null))
//			{
			
			memArr = members.split(",");
//			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return memArr;
			
		}

		return memArr;
	}

	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}
}
