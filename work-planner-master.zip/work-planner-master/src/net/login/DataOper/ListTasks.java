package net.login.DataOper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.JSONArray;
import org.json.JSONException;

public class ListTasks {
	public JSONArray getTasksData(String createdby) throws ClassNotFoundException, JSONException, SQLException {
		int count = 0;
		Connection connection = null;
		Class.forName("com.mysql.jdbc.Driver");
		ResultSet rs = null;
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1:3306/employees?allowPublicKeyRetrieval=true&useSSL=false", "root", "admin");
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from tasks where createdby = ?");
			preparedStatement.setString(1, createdby);
			
			rs = preparedStatement.executeQuery();
			//System.out.println("\n\nstatement "+Project.convert(rs));

		} catch (SQLException e) {
			System.out.println(e);
		}

		return Project.convert(rs);

	}
	
	public JSONArray getUserTasksData(String user) throws ClassNotFoundException, JSONException, SQLException {
		int count = 0;
		Connection connection = null;
		Class.forName("com.mysql.jdbc.Driver");
		ResultSet rs = null;
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1:3306/employees?allowPublicKeyRetrieval=true&useSSL=false", "root", "admin");
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from tasks where assignedTo = ?");
			preparedStatement.setString(1, user);
			
			rs = preparedStatement.executeQuery();
			//System.out.println("\n\nstatement "+Project.convert(rs));

		} catch (SQLException e) {
			System.out.println(e);
		}

		return Project.convert(rs);

	}
}
