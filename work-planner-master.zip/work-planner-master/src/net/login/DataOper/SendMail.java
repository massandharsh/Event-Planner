package net.login.DataOper;


public class SendMail {
  public static void Mail()  {
    
  }
}