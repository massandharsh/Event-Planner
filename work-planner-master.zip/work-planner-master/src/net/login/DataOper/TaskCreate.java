package net.login.DataOper;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.json.JSONException;


public class TaskCreate {
	


	public void createTask(String taskname, String taskdesc, String projectName, String taskfrom, String taskto, String assign, String createdby) throws ClassNotFoundException, JSONException {
		Connection connection=null;
		Class.forName("com.mysql.jdbc.Driver");
		try {
			 connection = DriverManager
		            .getConnection("jdbc:mysql://127.0.0.1:3306/employees?allowPublicKeyRetrieval=true&useSSL=false", "root", "admin");
		} catch (SQLException e) {
			printSQLException(e);
		}
		java.sql.Statement stmt = null;
		java.util.Date date1 = null, date2 = null;
		java.sql.Date sqlDate1 = null, sqlDate2 = null;
		try {
			date1 =  new SimpleDateFormat("yyyy-MM-dd").parse(taskfrom);
			date2 =  new SimpleDateFormat("yyyy-MM-dd").parse(taskto);
			sqlDate1 = new java.sql.Date(date1.getTime());
			sqlDate2 = new java.sql.Date(date2.getTime());
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String query = "INSERT INTO tasks(taskname, description, assignedTo, assignedon, dueon, status, createdby, projectname) VALUES (?,?,?,?,?,?,?,?)";
		System.out.println(query);
		try {
			PreparedStatement preparedStmt = connection.prepareStatement(query);
			
			preparedStmt.setString (1, taskname);
			preparedStmt.setString (2, taskdesc);
			preparedStmt.setString (3, assign);
			preparedStmt.setDate   (4, sqlDate1);
			preparedStmt.setDate   (5, sqlDate2);
			preparedStmt.setString (6, "In-Process");
			preparedStmt.setString (7, createdby);
			preparedStmt.setString (8, projectName);
			System.out.println(preparedStmt);
			preparedStmt.execute();
			SendMail.Mail();
			//connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	public void UpdateTaskStatus(String taskid,  String taskstatus) throws ClassNotFoundException {
		Connection connection=null;
		Class.forName("com.mysql.jdbc.Driver");
		try {
			 connection = DriverManager
		            .getConnection("jdbc:mysql://127.0.0.1:3306/employees?allowPublicKeyRetrieval=true&useSSL=false", "root", "admin");
		} catch (SQLException e) {
			printSQLException(e);
		}
		

		String query = "update tasks set status = ? where idtasks = ?";
		
		try {
			PreparedStatement preparedStmt = connection.prepareStatement(query);
			
			preparedStmt.setString (2, taskid);
			preparedStmt.setString (1, taskstatus);
			System.out.println(preparedStmt);
			preparedStmt.execute();
			
			//connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void UpdateTaskEdit(String taskid,  String field, String value) throws ClassNotFoundException, ParseException {
		Connection connection=null;
		Class.forName("com.mysql.jdbc.Driver");
		try {
			 connection = DriverManager
		            .getConnection("jdbc:mysql://127.0.0.1:3306/employees?allowPublicKeyRetrieval=true&useSSL=false", "root", "admin");
		} catch (SQLException e) {
			printSQLException(e);
		}
		

		String query = "update tasks set "+field+" = ? where idtasks = ?";
		
		try {
			PreparedStatement preparedStmt = connection.prepareStatement(query);
			if(field.equals("assignedon") || field.equals("dueon"))
			{
				java.util.Date date1 = null;
				java.sql.Date sqlDate1 = null;
				date1 =  new SimpleDateFormat("yyyy-MM-dd").parse(value);
				sqlDate1 = new java.sql.Date(date1.getTime());
				preparedStmt.setDate (1, sqlDate1);
			}
			else 
			{
				preparedStmt.setString (1, value);
			}
			preparedStmt.setString (2, taskid);
			System.out.println(preparedStmt);
			preparedStmt.execute();
			
			//connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}
	
	public void deleteTask(String taskId)
			throws ClassNotFoundException {

		Connection connection = null;
		Class.forName("com.mysql.jdbc.Driver");
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1:3306/employees?allowPublicKeyRetrieval=true&useSSL=false", "root", "admin");
		} catch (SQLException e) {
			System.out.println(e);
		}
	
		String query = "DELETE FROM tasks WHERE idtasks = ?";
		try {
			PreparedStatement preparedStmt = connection.prepareStatement(query);
			
			preparedStmt.setString (1, taskId);
			System.out.println(preparedStmt);
			preparedStmt.execute();
			
			//connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
