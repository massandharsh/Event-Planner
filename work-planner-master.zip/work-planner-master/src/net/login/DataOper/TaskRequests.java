package net.login.DataOper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.JSONArray;
import org.json.JSONException;



public class TaskRequests {
	Connection connection = null;
	public TaskRequests()
	{
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1:3306/employees?allowPublicKeyRetrieval=true&useSSL=false", "root", "admin");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public JSONArray getTaskRequestData(String manager) throws ClassNotFoundException, JSONException, SQLException {
		
		Class.forName("com.mysql.jdbc.Driver");
		ResultSet rs = null;
		try {

			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from task_requests where approver = ? and approval = 'Pending'");
			preparedStatement.setString(1, manager);

			rs = preparedStatement.executeQuery();

		} catch (SQLException e) {
			System.out.println(e);
		}

		return Project.convert(rs);

	}
	public void approveTaskRequest(String taskname, String manager) throws ClassNotFoundException
	{
		Class.forName("com.mysql.jdbc.Driver");
		ResultSet rs = null;
		TaskCreate obj = new TaskCreate();
		TaskRequests obj2 = new TaskRequests();
		try {
			
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from task_requests where idtask_requests = ?");
			preparedStatement.setString(1, taskname);

			rs = preparedStatement.executeQuery();
			if(rs.next())
			{
		
					obj.createTask(rs.getString("task_name"), rs.getString("description"), rs.getString("projectName"), rs.getString("assignedOn"), rs.getString("dueon"), rs.getString("assignedTo"), manager);
				
				preparedStatement = connection
						.prepareStatement("update task_requests set approval = 'Approved' where idtask_requests = ? and approver = ?");
				preparedStatement.setString(1, taskname);
				preparedStatement.setString(2, manager);
				preparedStatement.execute();
			}
			else
			{
				System.out.println("sad");
			}
			
		} catch (SQLException e) {
			System.out.println(e);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void rejectTaskRequest(String taskname, String manager) throws ClassNotFoundException
	{
		Class.forName("com.mysql.jdbc.Driver");
		
		 System.out.println("\n\nIN\n\n"+taskname+manager+"\n\n");
		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection
					.prepareStatement("update task_requests set approval = 'Rejected' where idtask_requests = ? and approver = ?");
			preparedStatement.setString(1, taskname);
			preparedStatement.setString(2, manager);
			preparedStatement.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
