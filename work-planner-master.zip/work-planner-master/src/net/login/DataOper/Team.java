package net.login.DataOper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

import org.json.JSONArray;
import org.json.JSONException;

public class Team {
	public JSONArray getMembers(String Manager) throws ClassNotFoundException, JSONException, SQLException {
		Connection connection = null;
		Class.forName("com.mysql.jdbc.Driver");
		ResultSet rs = null;
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1:3306/employees?allowPublicKeyRetrieval=true&useSSL=false", "root", "admin");
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from employee_central where managerid = ?");
			preparedStatement.setString(1, Manager);

			rs = preparedStatement.executeQuery();
			// System.out.println("\n\nstatement "+Project.convert(rs));

		} catch (SQLException e) {
			System.out.println("\n\nthis is the issue");
		}

		return Project.convert(rs);
	}
	
	public void addNewMember(String Manager, String uname, String uemail, String joinDate) throws ClassNotFoundException, ParseException {
		Connection connection = null;
		Class.forName("com.mysql.jdbc.Driver");
		ResultSet rs = null;
		java.util.Date date1 = null;
		String teamname,ManagerName = null;
		java.sql.Date sqlDate1 = null;
		DashSummary summaryObj = new DashSummary();
		String memberId[];
		String memberList="";
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1:3306/employees?allowPublicKeyRetrieval=true&useSSL=false", "root", "admin");
			PreparedStatement preparedStatement = connection
					.prepareStatement("select teamname from team where manager = ?");
			preparedStatement.setString(1, Manager);
			System.out.println("here I before");
			
			rs = preparedStatement.executeQuery();
			rs.next();
			teamname = rs.getString("teamname");
			System.out.println(teamname);
			preparedStatement = connection
					.prepareStatement("select name from employee_central where idemployee_central = ?");
			preparedStatement.setString(1, Manager);
			
			rs = preparedStatement.executeQuery();
			rs.next();
			ManagerName = rs.getString("name");
			String query = "INSERT INTO employee_central(idemployee_central, name, team, join_date, manager, managerid) VALUES (?,?,?,?,?,?)";
			
			try {
				PreparedStatement preparedStmt = connection.prepareStatement(query);
				date1 =  new SimpleDateFormat("yyyy-MM-dd").parse(joinDate);
				sqlDate1 = new java.sql.Date(date1.getTime());
				preparedStmt.setString (1, uemail);
				preparedStmt.setString (2, uname);
				preparedStmt.setString (3, teamname);
				preparedStmt.setDate   (4, sqlDate1);
				preparedStmt.setString   (5, ManagerName);
				preparedStmt.setString (6, Manager);
				System.out.println(preparedStmt);
				preparedStmt.execute();
				memberId = summaryObj.getTeamCount(Manager);
				if(memberId!=null)
				{
				memberList = Team.createList(memberId);
				memberList = memberList+","+uemail;
				}
				else {
					memberList = uemail+",";
				}
				
				System.out.println("\n\n\nlistt\n"+memberList);
				query = "UPDATE team set teammembers = ? where manager = ?";
				preparedStmt = connection.prepareStatement(query);
				preparedStmt.setString (1, memberList);
				preparedStmt.setString (2, Manager);
				preparedStmt.execute();
				
				//connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (SQLException e) {
			System.out.println(e);
		}
		
		String query = "INSERT INTO login(username, password, dispname, role) VALUES (?,?,?,?)";
		
		try {
			PreparedStatement stmt = connection.prepareStatement(query);
			stmt.setString (1, uemail);
			stmt.setString (2, "testpw");
			stmt.setString (3, uname);
			stmt.setString (4, "user");
			stmt.execute();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}		

	private static String createList(String[] memberId) {
		// TODO Auto-generated method stub
		String list="";
		for(int i=0;i<memberId.length;i++)
		{
			if(i!=memberId.length - 1)
			{
			list = list+memberId[i]+",";
			}
			else
			{
				list = list+memberId[i];
			}
		}
		return list;
	}
	
	public void deleteMember(String managerEmail, String memberEmail)
			throws ClassNotFoundException, SQLException {

		Connection connection = null;
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Statement stmt = null;
		ResultSet rs = null;
		String members;
		String[] memArr = null;
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1:3306/employees?allowPublicKeyRetrieval=true&useSSL=false", "root", "admin");
		} catch (SQLException e) {
			System.out.println(e);
		}
		
		String query = "select teammembers from team where manager = "+"'"+managerEmail+"'";

		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(query);
			rs.next();
			members = rs.getString("teammembers");
			memArr = members.split(",");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String list="";
		for(int i=0;i<memArr.length;i++)
		{
			if(i!=memArr.length - 1 && !memArr[i].equals(memberEmail))
			{
			list = list+memArr[i]+",";
			}
			else if(i==memArr.length - 1)
			{
				list = list+memArr[i];
			}
		}
		try {
		query = "UPDATE team set teammembers = ? where manager = ?";
		PreparedStatement preparedStmt = connection.prepareStatement(query);
		preparedStmt.setString (1, list);
		preparedStmt.setString (2, managerEmail);
		System.out.println(preparedStmt+list+managerEmail);
		preparedStmt.execute();
		
		} catch (SQLException e) {
			System.out.println("hello people");
			System.out.println(e);
		}
		query = "DELETE FROM employee_central WHERE idemployee_central = ?";
		PreparedStatement preparedStmt = connection.prepareStatement(query);
		preparedStmt.setString (1, memberEmail);
		//System.out.println(preparedStmt+list+managerEmail);
		preparedStmt.execute();
		
	
		
	}
	public void addManager(String managerEmail, String managerName, String teamname)
			throws ClassNotFoundException, SQLException {
		Connection connection  = null;
		Class.forName("com.mysql.jdbc.Driver");
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1:3306/employees?allowPublicKeyRetrieval=true&useSSL=false", "root", "admin");
			PreparedStatement preparedStatement = connection
					.prepareStatement("INSERT INTO login(username, password, dispname, role) VALUES (?,?,?,?)");
			preparedStatement.setString(1, managerEmail);
			preparedStatement.setString(2, "testpw");
			preparedStatement.setString(3, managerName);
			preparedStatement.setString(4, "admin");
			preparedStatement.execute();
			System.out.println("\n\ndone 1");
			preparedStatement = connection
					.prepareStatement("INSERT INTO team(teamname, manager) VALUES (?,?)");
			preparedStatement.setString(1, teamname);
			preparedStatement.setString(2, managerEmail);
			preparedStatement.execute();
			System.out.println("\n\ndone 2");
			java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
			preparedStatement = connection
					.prepareStatement("INSERT INTO employee_central(idemployee_central, name, team, join_date) VALUES (?,?,?,?)");
			preparedStatement.setString(1, managerEmail);
			preparedStatement.setString(2, managerName);
			preparedStatement.setString(3, teamname);
			preparedStatement.setDate(4, date);
			preparedStatement.execute();
			System.out.println("\n\ndone 3");
		} catch (SQLException e) {
			System.out.println("\n\nthis is the issue"+e);
		}
		
	}
	
}
