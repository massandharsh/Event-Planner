package net.login.DataOper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDashSummary {
	Connection connection;

	public UserDashSummary() {
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1:3306/employees?allowPublicKeyRetrieval=true&useSSL=false", "root", "admin");
		} catch (SQLException e) {
			System.out.println(e);
		}
	}

	public String getMyManager(String user) throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Statement stmt = null;
		ResultSet rs = null;
		String ManagerId = null;
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(
					"select managerid from employee_central where idemployee_central=" + "'" + user + "'");
			rs.next();
			ManagerId = rs.getString("managerid");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		return ManagerId;
	}

	public List<Category> projectList(String user) throws ClassNotFoundException {
		List<Category> listCategory = new ArrayList<>();
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Statement stmt = null;
		ResultSet rs = null;

		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery("SELECT * FROM projects where createdby = '" + user + "';");

			while (rs.next()) {
				String id = rs.getString("projname");
				String name = rs.getString("projname");
				Category category = new Category(id, name);

				listCategory.add(category);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return listCategory;
	}

	public List<Category> membersList(String user) throws ClassNotFoundException {
		List<Category> listCategory = new ArrayList<>();
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Statement stmt = null;
		ResultSet rs = null;

		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery("SELECT * FROM employee_central WHERE managerid = " + "'" + user + "'");
			while (rs.next()) {
				String id = rs.getString("idemployee_central");
				String name = rs.getString("name");
				Category category = new Category(id, name);
				listCategory.add(category);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return listCategory;
	}

	public int getProjectCount(String Manager) throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Statement stmt = null;
		ResultSet rs = null;
		int projectCount = 0;
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery("select count(*) from projects where createdby=" + "'" + Manager + "'");
			rs.next();
			projectCount = rs.getInt("count(*)");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Im testing");
			e.printStackTrace();
		}

		return projectCount;
	}

	public int getTaskCompletedCount(String user) throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Statement stmt = null;
		ResultSet rs = null;
		int taskCompletedCount = 0;
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(
					"select count(*) from tasks where status = 'Completed' and assignedTo=" + "'" + user + "'");
			if (rs.next()) {
				taskCompletedCount = rs.getInt("count(*)");
			} else {
				taskCompletedCount = 0;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return taskCompletedCount;
	}

	public int getTaskInProcessCount(String user) throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Statement stmt = null;
		ResultSet rs = null;
		int taskInProcessCount = 0;
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(
					"select count(*) from tasks where status = 'In-Process' and assignedTo=" + "'" + user + "'");
			if (rs.next()) {
				taskInProcessCount = rs.getInt("count(*)");
			} else {
				taskInProcessCount = 0;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return taskInProcessCount;
	}

	public String[] getTeamCount(String uname) throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Statement stmt = null;
		ResultSet rs = null;
		String members;
		String[] memArr = null;
		String query = "select teammembers from team where manager = " + "'" + uname + "'";
//		/System.out.println(uname);
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(query);
			rs.next();
			members = rs.getString("teammembers");
			memArr = members.split(",");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return memArr;
	}
}
