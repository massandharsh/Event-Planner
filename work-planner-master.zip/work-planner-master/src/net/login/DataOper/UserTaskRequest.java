package net.login.DataOper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class UserTaskRequest {
	public void createTaskRequest(String taskname, String taskdesc, String projectName, String taskfrom, String taskto, String assign, String createdby, String manager) throws ClassNotFoundException {
		Connection connection=null;
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("\n\nhello I am in again\n\n");
		try {
			 connection = DriverManager
		            .getConnection("jdbc:mysql://127.0.0.1:3306/employees?allowPublicKeyRetrieval=true&useSSL=false", "root", "admin");
		} catch (SQLException e) {
			System.out.println(e);
		}
		java.sql.Statement stmt = null;
		java.util.Date date1 = null, date2 = null;
		java.sql.Date sqlDate1 = null, sqlDate2 = null;
		try {
			date1 =  new SimpleDateFormat("yyyy-MM-dd").parse(taskfrom);
			date2 =  new SimpleDateFormat("yyyy-MM-dd").parse(taskto);
			sqlDate1 = new java.sql.Date(date1.getTime());
			sqlDate2 = new java.sql.Date(date2.getTime());
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String query = "INSERT INTO task_requests(task_name, description, assignedTo, assignedOn, dueon, status, requestedBy, projectName,approver,approval) VALUES (?,?,?,?,?,?,?,?,?,?)";
		System.out.println(query);
		try {
			PreparedStatement preparedStmt = connection.prepareStatement(query);
			
			preparedStmt.setString (1, taskname);
			preparedStmt.setString (2, taskdesc);
			preparedStmt.setString (3, assign);
			preparedStmt.setDate   (4, sqlDate1);
			preparedStmt.setDate   (5, sqlDate2);
			preparedStmt.setString (6, "In-Process");
			preparedStmt.setString (7, createdby);
			preparedStmt.setString (8, projectName);
			preparedStmt.setString (9, manager);
			preparedStmt.setString (10, "Pending");
			System.out.println(preparedStmt);
			preparedStmt.execute();
			
			//connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
