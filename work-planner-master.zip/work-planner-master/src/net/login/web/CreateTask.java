package net.login.web;

import java.io.IOException;

import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONException;


import net.login.DataOper.*;

@WebServlet("/CreateTask")
public class CreateTask extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//System.out.println("\n\n\nhelloooo innn\n\n\n");
		// TODO Auto-generated method stub
		TaskCreate tsk = new TaskCreate();
		String taskname = request.getParameter("tskname");
        String taskdesc = request.getParameter("tskdesc");
        String projectName = request.getParameter("projectName");
        String datefrom =request.getParameter("tskfrm");
        String dateto = request.getParameter("tskto");
        String assignedto = request.getParameter("assto");
        HttpSession session = request.getSession();
        String createdBy = (String) session.getAttribute("uid");
        //System.out.println(taskname+ taskdesc+ projectName+ datefrom+ dateto+ assignedto+ createdBy);
        try {
			tsk.createTask(taskname, taskdesc, projectName, datefrom, dateto, assignedto, createdBy);
			ServletContext sc = getServletContext();
			RequestDispatcher requestDispatcher = sc.getRequestDispatcher("/Dashboard");
        	requestDispatcher.forward(request, response);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
		//doGet(request, response);
	}

}
