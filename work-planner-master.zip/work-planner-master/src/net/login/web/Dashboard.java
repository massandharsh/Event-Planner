package net.login.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.login.DataOper.*;

/**
 * Servlet implementation class Dashboard
 */
@WebServlet("/Dashboard")
public class Dashboard extends HttpServlet {
	private static final long serialVersionUID = 1L;
    DashSummary summaryObj = new DashSummary();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Dashboard() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		try {
			HttpSession session = request.getSession();
			String data = (String) session.getAttribute("uid");
			getServletContext().setAttribute("ProjectCount",summaryObj.getProjectCount(data));
			getServletContext().setAttribute("TaskCompletedCount",summaryObj.getTaskCompletedCount(data));
			getServletContext().setAttribute("TaskInProcessCount",summaryObj.getTaskInProcessCount(data));
			List<Category> projectList = summaryObj.projectList(data);
			request.setAttribute("projectCategory", projectList);
			List<Category> membersList = summaryObj.membersList(data);
			request.setAttribute("membersCategory", membersList);
			 
			 System.out.println("\n\n\n \n"+data+"\n\n\n");
//			 if(summaryObj.getTeamCount(data) != null)
//			 {
			getServletContext().setAttribute("TeamCount",summaryObj.getTeamCount(data).length);
//			 }
//			 else {
//				 getServletContext().setAttribute("TeamCount",0);
//			 }
			getServletContext().setAttribute("users", summaryObj.getTeamCount(data));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.getRequestDispatcher("dashboard.jsp").forward(request, response);
	}

}
