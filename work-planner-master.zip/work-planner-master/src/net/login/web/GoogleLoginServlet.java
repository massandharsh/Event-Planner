package net.login.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.login.bean.LoginBean;
import net.login.database.LoginDao;


@WebServlet("/glogin")
public class GoogleLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private LoginDao loginDao;

    public void init() {
        loginDao = new LoginDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        String username = request.getParameter("gusername");
        String name = request.getParameter("gdispname");
        String imgurl = request.getParameter("gpic");
       //String password = request.getParameter("password");
        LoginBean loginBean = new LoginBean();
        loginBean.setUsername(username);
       //loginBean.setPassword(password);

        try {
            if (loginDao.validateGLogon(loginBean)) {
                //HttpSession session = request.getSession();
                // session.setAttribute("username",username);
            	loginBean.setDisplayName(name);
            	loginBean.setImgURL(imgurl);
            	getServletContext().setAttribute("name",name);
            	getServletContext().setAttribute("iurl",imgurl);
                HttpSession session = request.getSession();
                session.setAttribute("uid",loginBean.getUsername());
                String role = loginDao.checkRole(loginBean);
            	ServletContext sc = getServletContext();
            	if(role.equals("admin")) {
	            	RequestDispatcher requestDispatcher = sc.getRequestDispatcher("/Dashboard");
	            	requestDispatcher.forward(request, response);
            	}
            	
            	else if(role.equals("user")) {
            		RequestDispatcher requestDispatcher = sc.getRequestDispatcher("/UserDashboard");
	            	requestDispatcher.forward(request, response);
            	}
            	//request.getRequestDispatcher("dashboard.jsp").forward(request, response);
            //	System.out.println("\n\nentered\n\n");
              //  response.sendRedirect("loginsuccess.jsp");
            } else {
                HttpSession session = request.getSession();
                //session.setAttribute("user", username);
                System.out.println("\n\nentered\n\n");
                response.sendRedirect("login.jsp");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}