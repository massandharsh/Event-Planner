package net.login.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.login.DataOper.TaskRequests;

/**
 * Servlet implementation class TaskApproval
 */
@WebServlet("/TaskApproval")
public class TaskApproval extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TaskApproval() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		TaskRequests req = new TaskRequests();
		String taskname = request.getParameter("taskID");
        String approval = request.getParameter("appStatus");
        HttpSession session = request.getSession();
        String manager = (String) session.getAttribute("uid");
       
        if(approval.equals("Approve"))
        {
        	try {
				req.approveTaskRequest(taskname, manager);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	ServletContext sc = getServletContext();
			RequestDispatcher requestDispatcher = sc.getRequestDispatcher("/Dashboard");
        	requestDispatcher.forward(request, response);
        }
        else if(approval.equals("Reject"))
        {
        	try {
				req.rejectTaskRequest(taskname, manager);
				ServletContext sc = getServletContext();
				RequestDispatcher requestDispatcher = sc.getRequestDispatcher("/Dashboard");
	        	requestDispatcher.forward(request, response);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        else {
        	System.out.println("danger");
        }
	}

}
