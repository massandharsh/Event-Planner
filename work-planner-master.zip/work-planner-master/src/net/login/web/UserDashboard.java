package net.login.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.login.DataOper.Category;
import net.login.DataOper.DashSummary;
import net.login.DataOper.UserDashSummary;

/**
 * Servlet implementation class UserDashboard
 */
@WebServlet("/UserDashboard")
public class UserDashboard extends HttpServlet {
	private static final long serialVersionUID = 1L;
	DashSummary summaryObj = new DashSummary();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserDashboard() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		UserDashSummary summaryObj = new UserDashSummary();
		// TODO Auto-generated method stub
//		try {
			
			
			
			HttpSession session = request.getSession();
			String user = (String) session.getAttribute("uid");
			try {
				String manager = summaryObj.getMyManager(user);
				session.setAttribute("manager", manager);
				System.out.println(manager);
				
				getServletContext().setAttribute("ProjectCount", summaryObj.getProjectCount(manager));
				getServletContext().setAttribute("TaskCompletedCount", summaryObj.getTaskCompletedCount(user));
				getServletContext().setAttribute("TaskInProcessCount", summaryObj.getTaskInProcessCount(user));
				getServletContext().setAttribute("TeamCount", summaryObj.getTeamCount(manager).length);
				
				List<Category> projectList = summaryObj.projectList(manager);
				request.setAttribute("projectCategory", projectList);
				List<Category> membersList = summaryObj.membersList(manager);
				request.setAttribute("membersCategory", membersList);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		request.getRequestDispatcher("UserDashboard.jsp").forward(request, response);

	}
	

}
